# Calorie Counter Android App

A native Android calorie and nutrition tracker built with Kotlin, Jetpack Compose, Room, CameraX, ML Kit and the Open Food Facts API.

## Features

- Scan food-packaging barcodes
- Retrieve nutrition data from Open Food Facts
- Enter the amount eaten in grams or millilitres
- Calculate calories, protein, carbohydrate and fat for the entered amount
- Add foods manually when a barcode is not found
- Save recipes with multiple ingredients and servings
- Log one serving of a recipe to today's food diary
- Set and edit a daily calorie target

## GitHub Actions build

This repository is designed so that `CalorieCounter.zip` can be uploaded as a single file.
The GitHub Actions workflow unzips it and builds `app-debug.apk`.
