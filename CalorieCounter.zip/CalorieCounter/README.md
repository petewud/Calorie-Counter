# Calorie Counter 2.1

Complete Android project for the existing ZIP-based GitHub Actions workflow. Upload the replacement archive as CalorieCounter.zip at repository root; leave .github/workflows/build-apk.yml unchanged. No update scripts are required.

## Changes
- Known nutrient sums survive missing ingredients and scaling into recipe portions and diary entries.
- Compact home-screen reference labels, expanded-item nutrient impact bars, no duplicate Add button.
- Food/Weight tabs. Dated editable measurements, pinch zoom, drag pan, tap-to-edit points and an accessible measurement list. Target weight in onboarding/settings and on the chart.
- Compact 2x1 calorie widget; remove and re-add an existing widget if it retains its old size. Actual launcher dimensions vary.
- Android navigation buttons share the bottom navigation background in light/dark mode.
- Database version 4 adds weight_records without dropping existing tables. profile_v2 preferences, application ID, diary JSON and recipe JSON remain compatible.
- Backups include weights/target; old format-2 backups without weights are accepted.

## Existing recipe entries
Older logged recipes are snapshots. Missing fibre cannot be reconstructed from that snapshot alone. Expand a logged recipe that uniquely matches a saved recipe name and choose Recover missing values from saved recipe. Confirm only if the current saved recipe represents that meal. Only unknown values are filled; known historical values are retained. Otherwise edit/relog the meal. New recipe entries retain partial sums automatically.

## Weight
One measurement per date, kg units, no future dates. Existing users can add a first dated measurement without repeating onboarding. New users' starting weight is recorded today after setup. Weight updates do not automatically change calorie targets. Target weight can be above or below starting weight. The chart is resettable, zoomable and pannable; tap a point or a measurement row to edit/delete.

## Update safety
Export an in-app backup before installing. Install over the existing app; do not uninstall to bypass a signature mismatch. Keep the existing GitHub signing-key cache. No app data is deliberately deleted by this upgrade.

## Validation
Nine JVM regression tests are included for known/unknown sums, nested portion scaling, old JSON/profile compatibility and weight serialization. The existing workflow runs them before producing the APK. XML, archive integrity, source structure and SQL compatibility are checked during packaging. Android compilation/device testing must still run on GitHub/your phone; no APK was compiled in the generation environment.

## Data
Open Food Facts (ODbL). Searches/barcodes are sent to that service. Nutrition may be incomplete; unknown fields are not zero. Weight, diary and recipe data are stored locally.
