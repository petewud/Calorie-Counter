# Calorie Counter 2.2

Complete replacement project for the existing ZIP-based GitHub build workflow. Upload this archive as CalorieCounter.zip at repository root. Keep the YAML and signing-key cache unchanged. No update scripts or extra dependencies are required.

## 2.2 changes
- Weight summary is just current weight and weight lost/gained since the first dated measurement.
- Save weight is beside the date button. Target editing is in Settings only. Removed the extra progress and calorie-target paragraphs.
- Optional target-weight date in onboarding/settings, retained in backups.
- Green goal trajectory from first measured weight/date to target weight/date. Without a target date, a horizontal target line remains.
- Orange dashed trend projection: least-squares slope over up to 28 days ending at the latest measurement, at least three distinct dates spanning seven days. Anchored at the latest measured weight. Projects to the target date (up to 365 days) or 90 days by default, stopping at the chart's supported weight boundary. This is an estimate, not a guarantee or recommended rate of loss/gain.
- Long numeric Open Food Facts search IDs accepted (up to 64 digits), including internal IDs longer than retail barcodes. Failed product lookups show a message beside the selected result. Actual nutrition depends on the database record.
- No restaurant tab/catalogue in this version.

## Existing features retained
Partial nutrient sums, recipe portions, diary impact bars, calendar history, editable food amounts/nutrition, serving conversions, search/scanning, 2x1 widget, profile/calorie targets, local backups, editable weight history and interactive graph. Older recipe snapshots are not silently rewritten; expand an entry to recover missing values from a matching current saved recipe if appropriate.

## Install
Export a backup in Settings, replace only CalorieCounter.zip on GitHub, commit, wait for Actions, and install the resulting APK over the existing app. Do not uninstall to bypass a signing mismatch. Retain the persistent debug signing key.

## Data compatibility
Same application ID, calorie_counter.db version 4, profile_v2 preferences and format-2 JSON backups. Profile adds nullable targetWeightDate, so older profiles need no reset. Weight table upgrade from database v3 remains additive. No intentional data deletion.

## Validation
Includes 14 JVM tests for partial sums, portions, legacy JSON, long identifiers, trend arithmetic and target-date persistence. GitHub runs testDebugUnitTest assembleDebug. Local packaging checks XML, lexical source structure, SQL compatibility, independent trend arithmetic and ZIP integrity. Android compilation/device testing are not available in the generation environment and must be verified in GitHub/on device.

Food data: Open Food Facts (ODbL). Missing fields remain unknown. Searches/barcodes go to that service; the diary, recipes, profile and measurements remain local.
