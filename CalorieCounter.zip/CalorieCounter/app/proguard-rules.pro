# Keep Gson-generated models
-keep class com.example.caloriecounter.data.** { *; }
