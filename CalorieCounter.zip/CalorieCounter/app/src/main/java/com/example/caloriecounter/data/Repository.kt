package com.example.caloriecounter.data

class Repository(
    private val api: OpenFoodFactsApi,
    private val dao: AppDao
) {

    suspend fun getProduct(barcode: String): ProductEntity? {
        return try {
            val response = api.getProduct(barcode)
            val product = response.product ?: return null
            val n = product.nutriments ?: return null

            val kcal = n.kcal ?: n.energyKj?.div(4.184) ?: 0.0

            val entity = ProductEntity(
                barcode = barcode,
                name = product.productName ?: "Unknown product",
                brand = product.brands,
                imageUrl = product.imageFrontUrl,
                kcalPer100 = kcal,
                proteinPer100 = n.protein ?: 0.0,
                carbsPer100 = n.carbs ?: 0.0,
                sugarsPer100 = n.sugars ?: 0.0,
                fatPer100 = n.fat ?: 0.0,
                saturatedFatPer100 = n.saturatedFat ?: 0.0,
                fibrePer100 = n.fibre ?: 0.0,
                saltPer100 = n.salt ?: 0.0
            )

            dao.insertProduct(entity)
            entity
        } catch (_: Exception) {
            null
        }
    }
}
