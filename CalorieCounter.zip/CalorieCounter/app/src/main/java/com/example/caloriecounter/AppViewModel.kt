package com.example.caloriecounter

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.caloriecounter.data.AppDatabase
import com.example.caloriecounter.data.DiaryEntryEntity
import com.example.caloriecounter.data.OffApi
import com.example.caloriecounter.data.ProductEntity
import com.example.caloriecounter.data.RecipeEntity
import com.example.caloriecounter.data.RecipeIngredientEntity
import com.example.caloriecounter.data.Repository
import com.example.caloriecounter.data.SettingsEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = AppDatabase.get(application).dao()
    private val repository = Repository(OffApi.service, dao)

    val settings = dao.settingsFlow()
        .map { it ?: SettingsEntity() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsEntity())

    fun entriesForDate(date: String) = dao.entriesForDate(date)

    fun recipes() = dao.recipes()

    fun fetchProduct(barcode: String, onResult: (ProductEntity?) -> Unit) {
        viewModelScope.launch {
            onResult(repository.getProduct(barcode))
        }
    }

    fun addEntry(entry: DiaryEntryEntity) {
        viewModelScope.launch { dao.insertEntry(entry) }
    }

    fun deleteEntry(entry: DiaryEntryEntity) {
        viewModelScope.launch { dao.deleteEntry(entry.id) }
    }

    fun setCalorieTarget(target: Int) {
        viewModelScope.launch {
            dao.upsertSettings(SettingsEntity(calorieTarget = target))
        }
    }

    fun saveRecipe(
        name: String,
        servings: Int,
        ingredients: List<RecipeIngredientEntity>,
        onSaved: (Long) -> Unit
    ) {
        viewModelScope.launch {
            val recipeId = dao.insertRecipe(RecipeEntity(name = name, servings = servings))
            ingredients.forEach { dao.insertIngredient(it.copy(recipeId = recipeId)) }
            onSaved(recipeId)
        }
    }

    fun deleteRecipe(recipe: RecipeEntity) {
        viewModelScope.launch { dao.deleteRecipe(recipe.id) }
    }

    suspend fun ingredientsFor(recipeId: Long): List<RecipeIngredientEntity> =
        dao.ingredientsFor(recipeId)

    fun logRecipeServing(
        recipe: RecipeEntity,
        ingredients: List<RecipeIngredientEntity>,
        date: String,
        mealType: String
    ) {
        viewModelScope.launch {
            if (ingredients.isEmpty() || recipe.servings <= 0) return@launch

            val totalKcal = ingredients.sumOf { it.kcalPer100 * it.quantityGrams / 100.0 }
            val totalProtein = ingredients.sumOf { it.proteinPer100 * it.quantityGrams / 100.0 }
            val totalCarbs = ingredients.sumOf { it.carbsPer100 * it.quantityGrams / 100.0 }
            val totalFat = ingredients.sumOf { it.fatPer100 * it.quantityGrams / 100.0 }

            dao.insertEntry(
                DiaryEntryEntity(
                    date = date,
                    mealType = mealType,
                    barcode = null,
                    name = recipe.name + " (1 serving)",
                    quantityGrams = 0.0,
                    kcal = totalKcal / recipe.servings,
                    protein = totalProtein / recipe.servings,
                    carbs = totalCarbs / recipe.servings,
                    fat = totalFat / recipe.servings
                )
            )
        }
    }
}
