package com.example.caloriecounter.data

import com.google.gson.annotations.SerializedName
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import okhttp3.OkHttpClient

data class OffResponse(
    val status: Int?,
    val product: OffProduct?
)

data class OffProduct(
    @SerializedName("product_name") val productName: String?,
    val brands: String?,
    @SerializedName("image_front_url") val imageFrontUrl: String?,
    val nutriments: OffNutriments?
)

data class OffNutriments(
    @SerializedName("energy-kcal_100g") val kcal: Double?,
    @SerializedName("energy_100g") val energyKj: Double?,
    @SerializedName("proteins_100g") val protein: Double?,
    @SerializedName("carbohydrates_100g") val carbs: Double?,
    @SerializedName("sugars_100g") val sugars: Double?,
    @SerializedName("fat_100g") val fat: Double?,
    @SerializedName("saturated-fat_100g") val saturatedFat: Double?,
    @SerializedName("fiber_100g") val fibre: Double?,
    @SerializedName("salt_100g") val salt: Double?
)

interface OpenFoodFactsApi {

    @GET("api/v2/product/{barcode}.json")
    suspend fun getProduct(
        @Path("barcode") barcode: String,
        @Query("fields") fields: String = "product_name,brands,image_front_url,nutriments"
    ): OffResponse
}

object OffApi {
    val service: OpenFoodFactsApi by lazy {
        val client = OkHttpClient.Builder()
            .addInterceptor { chain ->
                chain.proceed(
                    chain.request().newBuilder()
                        .header(
                            "User-Agent",
                            "CalorieCounter - Android - Version 1.0"
                        )
                        .build()
                )
            }
            .build()

        Retrofit.Builder()
            .baseUrl("https://world.openfoodfacts.org/")
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(OpenFoodFactsApi::class.java)
    }
}
