package com.example.caloriecounter.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.caloriecounter.AppViewModel

@Composable
fun App(viewModel: AppViewModel = viewModel()) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = currentRoute == "today",
                    onClick = {
                        navController.navigate("today") {
                            popUpTo(navController.graph.findStartDestination().id)
                            launchSingleTop = true
                        }
                    },
                    icon = { Icon(Icons.Default.Home, contentDescription = null) },
                    label = { Text("Today") }
                )
                NavigationBarItem(
                    selected = currentRoute == "scan",
                    onClick = {
                        navController.navigate("scan") {
                            popUpTo(navController.graph.findStartDestination().id)
                            launchSingleTop = true
                        }
                    },
                    icon = { Icon(Icons.Default.Add, contentDescription = null) },
                    label = { Text("Scan") }
                )
                NavigationBarItem(
                    selected = currentRoute == "recipes",
                    onClick = {
                        navController.navigate("recipes") {
                            popUpTo(navController.graph.findStartDestination().id)
                            launchSingleTop = true
                        }
                    },
                    icon = { Icon(Icons.Default.List, contentDescription = null) },
                    label = { Text("Recipes") }
                )
                NavigationBarItem(
                    selected = currentRoute == "settings",
                    onClick = {
                        navController.navigate("settings") {
                            popUpTo(navController.graph.findStartDestination().id)
                            launchSingleTop = true
                        }
                    },
                    icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                    label = { Text("Settings") }
                )
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = "today",
            modifier = Modifier.padding(padding)
        ) {
            composable("today") {
                TodayScreen(
                    viewModel = viewModel,
                    onScan = { navController.navigate("scan") },
                    onAddManually = { navController.navigate("add?barcode=") }
                )
            }
            composable("scan") {
                ScanScreen(
                    onBarcode = { barcode ->
                        navController.navigate("add?barcode=$barcode")
                    }
                )
            }
            composable(
                route = "add?barcode={barcode}",
                arguments = listOf(navArgument("barcode") { defaultValue = "" })
            ) { entry ->
                val barcode = entry.arguments?.getString("barcode").orEmpty()
                AddFoodScreen(
                    viewModel = viewModel,
                    barcode = barcode,
                    onSaved = { navController.popBackStack() }
                )
            }
            composable("recipes") {
                RecipesScreen(
                    viewModel = viewModel,
                    onNewRecipe = { navController.navigate("recipeEditor") }
                )
            }
            composable("recipeEditor") {
                RecipeEditorScreen(
                    viewModel = viewModel,
                    onSaved = { navController.popBackStack() }
                )
            }
            composable("settings") {
                SettingsScreen(viewModel = viewModel)
            }
        }
    }
}
