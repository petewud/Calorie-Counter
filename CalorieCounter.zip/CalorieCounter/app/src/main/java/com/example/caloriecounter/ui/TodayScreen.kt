package com.example.caloriecounter.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.caloriecounter.AppViewModel
import java.time.LocalDate

@Composable
fun TodayScreen(
    viewModel: AppViewModel,
    onScan: () -> Unit,
    onAddManually: () -> Unit
) {
    val date = LocalDate.now().toString()
    val entries by viewModel.entriesForDate(date).collectAsStateWithLifecycle(initialValue = emptyList())
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    val consumed = entries.sumOf { it.kcal }
    val target = settings.calorieTarget.toDouble()
    val remaining = target - consumed
    val progress = if (target > 0) (consumed / target).toFloat().coerceIn(0f, 1f) else 0f

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Today", style = MaterialTheme.typography.headlineMedium)

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Calories", style = MaterialTheme.typography.titleMedium)
                Text(
                    "%.0f / %.0f kcal".format(consumed, target),
                    style = MaterialTheme.typography.headlineSmall
                )
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                )
                Text(
                    if (remaining >= 0) "%.0f kcal remaining".format(remaining)
                    else "%.0f kcal over target".format(-remaining),
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onScan) {
                Text("Scan barcode")
            }
            OutlinedButton(onClick = onAddManually) {
                Text("Add manually")
            }
        }

        Text("Food logged", style = MaterialTheme.typography.titleMedium)

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(entries) { entry ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(entry.name, style = MaterialTheme.typography.titleSmall)
                        Text(entry.mealType)
                        Text(
                            "%.0f kcal | %.1fg protein | %.1fg carbs | %.1fg fat"
                                .format(entry.kcal, entry.protein, entry.carbs, entry.fat)
                        )
                        TextButton(onClick = { viewModel.deleteEntry(entry) }) {
                            Text("Delete")
                        }
                    }
                }
            }
        }
    }
}
