package com.example.caloriecounter.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.caloriecounter.AppViewModel
import com.example.caloriecounter.data.RecipeIngredientEntity

@Composable
fun RecipeEditorScreen(
    viewModel: AppViewModel,
    onSaved: () -> Unit
) {
    var recipeName by remember { mutableStateOf("") }
    var servings by remember { mutableStateOf("1") }

    var barcode by remember { mutableStateOf("") }
    var manualName by remember { mutableStateOf("") }
    var manualKcal by remember { mutableStateOf("") }
    var manualProtein by remember { mutableStateOf("") }
    var manualCarbs by remember { mutableStateOf("") }
    var manualFat by remember { mutableStateOf("") }
    var manualQuantity by remember { mutableStateOf("") }

    val ingredients = remember { mutableStateListOf<RecipeIngredientEntity>() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("New recipe", style = MaterialTheme.typography.headlineSmall)

        OutlinedTextField(
            value = recipeName,
            onValueChange = { recipeName = it },
            label = { Text("Recipe name") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = servings,
            onValueChange = { servings = it },
            label = { Text("Number of servings") },
            modifier = Modifier.fillMaxWidth()
        )

        Text("Add scanned ingredient", style = MaterialTheme.typography.titleMedium)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = barcode,
                onValueChange = { barcode = it },
                label = { Text("Barcode") },
                modifier = Modifier.weight(1f)
            )
            Button(
                onClick = {
                    if (barcode.isNotBlank()) {
                        viewModel.fetchProduct(barcode) { product ->
                            if (product != null) {
                                ingredients.add(
                                    RecipeIngredientEntity(
                                        recipeId = 0,
                                        name = product.name,
                                        quantityGrams = 100.0,
                                        kcalPer100 = product.kcalPer100,
                                        proteinPer100 = product.proteinPer100,
                                        carbsPer100 = product.carbsPer100,
                                        fatPer100 = product.fatPer100
                                    )
                                )
                                barcode = ""
                            }
                        }
                    }
                }
            ) {
                Text("Add")
            }
        }

        Text("Add manual ingredient", style = MaterialTheme.typography.titleMedium)

        OutlinedTextField(
            value = manualName,
            onValueChange = { manualName = it },
            label = { Text("Ingredient name") },
            modifier = Modifier.fillMaxWidth()
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = manualKcal,
                onValueChange = { manualKcal = it },
                label = { Text("kcal / 100g") },
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = manualQuantity,
                onValueChange = { manualQuantity = it },
                label = { Text("Quantity g") },
                modifier = Modifier.weight(1f)
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = manualProtein,
                onValueChange = { manualProtein = it },
                label = { Text("Protein g") },
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = manualCarbs,
                onValueChange = { manualCarbs = it },
                label = { Text("Carbs g") },
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = manualFat,
                onValueChange = { manualFat = it },
                label = { Text("Fat g") },
                modifier = Modifier.weight(1f)
            )
        }

        OutlinedButton(
            onClick = {
                val quantity = manualQuantity.toDoubleOrNull() ?: 0.0
                if (manualName.isNotBlank() && quantity > 0) {
                    ingredients.add(
                        RecipeIngredientEntity(
                            recipeId = 0,
                            name = manualName,
                            quantityGrams = quantity,
                            kcalPer100 = manualKcal.toDoubleOrNull() ?: 0.0,
                            proteinPer100 = manualProtein.toDoubleOrNull() ?: 0.0,
                            carbsPer100 = manualCarbs.toDoubleOrNull() ?: 0.0,
                            fatPer100 = manualFat.toDoubleOrNull() ?: 0.0
                        )
                    )
                    manualName = ""
                    manualKcal = ""
                    manualProtein = ""
                    manualCarbs = ""
                    manualFat = ""
                    manualQuantity = ""
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Add manual ingredient")
        }

        Text("Ingredients", style = MaterialTheme.typography.titleMedium)

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(ingredients) { ingredient ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(ingredient.name)
                        Text("%.0fg".format(ingredient.quantityGrams))
                        Text(
                            "%.0f kcal per 100g".format(ingredient.kcalPer100)
                        )
                        TextButton(onClick = { ingredients.remove(ingredient) }) {
                            Text("Remove")
                        }
                    }
                }
            }
        }

        Button(
            onClick = {
                val servingsValue = servings.toIntOrNull() ?: 1
                if (recipeName.isNotBlank() && ingredients.isNotEmpty()) {
                    viewModel.saveRecipe(
                        name = recipeName,
                        servings = servingsValue,
                        ingredients = ingredients.toList()
                    ) {
                        onSaved()
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Save recipe")
        }
    }
}
