package com.example.caloriecounter
import kotlin.math.roundToInt
import com.google.gson.Gson
import java.time.LocalDate
val nutrientNames=listOf("Calories","Protein","Carbohydrate","Fat","Saturated fat","Total sugars","Fibre","Salt")
val nutrientUnits=listOf("kcal","g","g","g","g","g","g","g")
val referenceDefaults=listOf(2000.0,50.0,260.0,70.0,20.0,90.0,30.0,6.0)
data class Nutrients(val values:List<Double?> = List(8){null},val missingCounts:List<Int>?=null){
 operator fun times(f:Double)=Nutrients(values.map{it?.times(f)},missingCounts)
 operator fun get(i:Int):Double?=values.getOrNull(i)
 fun missing(i:Int):Int=missingCounts?.getOrNull(i)?:if(this[i]==null)1 else 0
}
fun sumNutrients(items:List<Nutrients>)=Nutrients((0..7).map{i->val known=items.mapNotNull{it[i]};if(items.isNotEmpty()&&known.isEmpty())null else known.sum()},(0..7).map{i->items.sumOf{it.missing(i)}})
fun partialTotal(items:List<Nutrients>,i:Int)=items.sumOf{it[i]?:0.0}
fun numberText(n:Double?,decimals:Int=1):String=n?.let{("%.${decimals}f").format(java.util.Locale.UK,it)}?:"not recorded"
fun compact(n:Double):String=if(n==n.toLong().toDouble())n.toLong().toString()else numberText(n)
data class Food(val name:String="",val barcode:String="",val brand:String="",val nutrients:Nutrients=Nutrients(),val servingLabel:String="serving",val servingGrams:Double?=null,val basis:String="g")
data class Ingredient(val food:Food,val amount:Double=100.0,val unit:String="g",val unitGrams:Double=1.0){fun total()=food.nutrients*(amount*unitGrams/100.0)}
data class Recipe(val id:Long=0,val name:String="",val servings:Int=1,val ingredients:List<Ingredient> = emptyList()){
 fun total()=sumNutrients(ingredients.map{it.total()})
 fun servingFood()=Food(name,nutrients=total()*(1.0/servings.coerceAtLeast(1)),servingLabel="portion",servingGrams=100.0)
}
data class Entry(val id:Long=0,val date:String,val food:Food,val amount:Double=100.0,val unit:String="g",val unitGrams:Double=1.0){fun total()=food.nutrients*(amount*unitGrams/100.0)}
data class Profile(val completed:Boolean=false,val sex:String="Female",val age:Int=30,val height:Double=170.0,val weight:Double=70.0,val activity:Double=1.2,val targets:List<Double> = referenceDefaults,val ukFirst:Boolean=true,val targetWeight:Double?=null,val targetWeightDate:String?=null,val autoCalorieTarget:Boolean=false,val autoGoalEligible:Boolean=false){fun estimate()=estimateCalories(sex,age,height,weight,activity)}
data class WeightRecord(val id:Long=0,val date:String,val kg:Double)
data class WeightTrend(val startDay:Long,val startKg:Double,val slopeKgPerDay:Double){fun at(day:Long)=startKg+(day-startDay)*slopeKgPerDay}
// Ordinary least-squares slope against elapsed days, anchored at the latest actual measurement.
fun weightTrend(records:List<WeightRecord>):WeightTrend?{
 val ordered=records.sortedBy{it.date}.distinctBy{it.date};val last=ordered.lastOrNull()?:return null
 val end=LocalDate.parse(last.date).toEpochDay();val recent=ordered.filter{LocalDate.parse(it.date).toEpochDay()>=end-28}
 if(recent.size<3||end-LocalDate.parse(recent.first().date).toEpochDay()<7)return null
 val xs=recent.map{(LocalDate.parse(it.date).toEpochDay()-end).toDouble()};val ys=recent.map{it.kg};val mx=xs.average();val my=ys.average()
 val denom=xs.sumOf{(it-mx)*(it-mx)};if(denom<=0)return null
 val slope=xs.indices.sumOf{(xs[it]-mx)*(ys[it]-my)}/denom
 return WeightTrend(end,last.kg,slope)
}
fun validFoodCode(code:String)=code.length in 1..64&&code.all{it in '0'..'9'}
fun estimateCalories(sex:String,age:Int,height:Double,weight:Double,activity:Double):Double=((10*weight+6.25*height-5*age+if(sex=="Male")5 else -161)*activity).roundToInt().toDouble()
val json=Gson()

data class CalorieGoalEstimate(val calories:Double?,val limited:Boolean=false,val message:String="")
fun calorieGoalEstimate(p:Profile,today:LocalDate=LocalDate.now()):CalorieGoalEstimate{
 if(!p.autoGoalEligible)return CalorieGoalEstimate(null,message="Confirm eligibility before enabling automatic estimates.")
 if(p.age !in 18..120||!p.height.isFinite()||p.height<=0||!p.weight.isFinite()||p.weight<=0||p.sex !in listOf("Male","Female"))return CalorieGoalEstimate(null,message="Valid adult profile details are required.")
 val goal=p.targetWeight?.takeIf{it.isFinite()&&it>0}?:return CalorieGoalEstimate(null,message="Set a target weight first.")
 val date=p.targetWeightDate?.let{runCatching{LocalDate.parse(it)}.getOrNull()}?:return CalorieGoalEstimate(null,message="Set a target date first.")
 val days=date.toEpochDay()-today.toEpochDay()
 if(days<=0)return CalorieGoalEstimate(null,message="The target date has passed. Automatic estimates are paused.")
 val metres=p.height/100.0
 if(p.weight/(metres*metres)<18.5||goal/(metres*metres)<18.5)return CalorieGoalEstimate(null,message="Automatic adjustment is unavailable for underweight current or target weights. Seek individual advice.")
 val maintenance=p.estimate()
 if(!maintenance.isFinite()||maintenance<=0)return CalorieGoalEstimate(null,message="Cannot estimate maintenance calories from this profile.")
 // A rough starting estimate, not the dynamic NIH Body Weight Planner model.
 val wanted=(goal-p.weight)*7700.0/days.toDouble()
 val adjustment=wanted.coerceIn(-500.0,300.0)
 val floor=if(p.sex=="Male")1500.0 else 1200.0
 val actual=maxOf(floor,maintenance+adjustment)
 val limited=kotlin.math.abs(wanted-adjustment)>0.5||actual>maintenance+adjustment+0.5
 return CalorieGoalEstimate(kotlin.math.round(actual),limited,if(limited)"Limited estimate: this deadline may not be achievable within the app's limits. Choose a later date or seek individual advice."else "Approximate starting target; weight change is not guaranteed and metabolism changes over time.")
}

fun calorieFill(used:Double,target:Double):Int=if(target>0&&used.isFinite()&&target.isFinite())((used/target).coerceIn(0.0,1.0)*1000).toInt()else 0

data class Favourite(val id:String,val ingredient:Ingredient)
fun favouriteId(i:Ingredient):String{
 val key=i.food.barcode.ifBlank{listOf(i.food.name.trim().lowercase(java.util.Locale.UK),i.food.basis,i.food.servingLabel).joinToString("|")}
 return java.security.MessageDigest.getInstance("SHA-256").digest(key.toByteArray(Charsets.UTF_8)).joinToString(""){"%02x".format(it)}
}
fun validFavourite(i:Ingredient)=i.food.name.isNotBlank()&&i.amount.isFinite()&&i.amount>0&&i.unitGrams.isFinite()&&i.unitGrams>0&&i.food.nutrients.values.size==8&&i.food.nutrients[0]!=null&&i.food.nutrients.values.all{it==null||(it.isFinite()&&it>=0)}

fun toggledFavourites(items:List<Favourite>,i:Ingredient):List<Favourite>{
 val id=favouriteId(i)
 if(items.any{it.id==id})return items.filter{it.id!=id}
 require(validFavourite(i)){"Complete the food name, calories and amount before saving a favourite"}
 return items+Favourite(id,i)
}
