@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.caloriecounter
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
@Composable
fun AddScreen(profile:Profile,favourites:List<Favourite>,onSelect:(Food)->Unit,onFavouriteSelect:(Ingredient)->Unit,onRemoveFavourite:(String)->Unit,onManual:()->Unit,onScan:()->Unit,onRestaurants:()->Unit){
 var tab by androidx.compose.runtime.saveable.rememberSaveable{mutableIntStateOf(0)}
 Column(Modifier.fillMaxSize()){
  TabRow(selectedTabIndex=tab){Tab(selected=tab==0,onClick={tab=0},text={Text("Food")});Tab(selected=tab==1,onClick={tab=1},text={Text("Favourites")})}
  Box(Modifier.weight(1f)){if(tab==0)SearchScreen(profile,onSelect,onManual,onScan,onRestaurants)else FavouritesScreen(favourites,onFavouriteSelect,onRemoveFavourite)}
 }
}
@Composable
fun FavouritesScreen(favourites:List<Favourite>,onUse:(Ingredient)->Unit,onRemove:(String)->Unit){
 var query by remember{mutableStateOf("")}
 Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
  Text("Favourites",style=MaterialTheme.typography.headlineSmall)
  OutlinedTextField(query,{query=it},label={Text("Search favourites")},modifier=Modifier.fillMaxWidth())
  if(favourites.isEmpty())Text("No favourites yet. Use Save to favourites on a food, or the star on a diary entry.")
  val shown=favourites.filter{it.ingredient.food.name.contains(query,true)||it.ingredient.food.brand.contains(query,true)}
  LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(8.dp)){
   items(shown,key={it.id}){f->val i=f.ingredient;Card(Modifier.fillMaxWidth()){
    Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
     Text(i.food.name,style=MaterialTheme.typography.titleMedium)
     if(i.food.brand.isNotBlank())Text(i.food.brand)
     Text("${numberText(i.amount)}${if(i.unit in listOf("g","ml"))""else " "}${i.unit} · ${numberText(i.total()[0],0)}kcal")
     Row{Button(onClick={onUse(i)}){Text("Add item")};IconButton(onClick={onRemove(f.id)}){Icon(Icons.Default.Delete,"Remove ${i.food.name} from favourites")}}
    }
   }}
  }
 }
}
@Composable
fun RecipePortionForm(initial:Ingredient,onCancel:()->Unit,onReplace:()->Unit,onSave:(Ingredient)->Unit,onFavourite:(Ingredient)->Unit){
 var quantity by remember{mutableStateOf(initial.amount.toString())};val q=quantity.toDoubleOrNull()?.takeIf{it.isFinite()&&it>0}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).imePadding().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
  Text(initial.food.name,style=MaterialTheme.typography.headlineSmall);NumericField(quantity,{quantity=it},"Number of recipe portions");NutritionText(initial.food.nutrients*(q?:0.0))
  Button(enabled=q!=null,onClick={onSave(initial.copy(amount=q!!,unit="portion",unitGrams=100.0))}){Text("Save")}
  OutlinedButton(enabled=q!=null,onClick={onFavourite(initial.copy(amount=q!!,unit="portion",unitGrams=100.0))}){Text("Save to favourites")}
  OutlinedButton(onClick=onReplace){Text("Choose another food")};TextButton(onClick=onCancel){Text("Cancel")}
 }
}
