package com.example.caloriecounter.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.caloriecounter.AppViewModel
import com.example.caloriecounter.data.DiaryEntryEntity
import com.example.caloriecounter.data.ProductEntity
import java.time.LocalDate

private fun scale(per100: Double, grams: Double): Double =
    per100 * grams / 100.0

@Composable
fun AddFoodScreen(
    viewModel: AppViewModel,
    barcode: String,
    onSaved: () -> Unit
) {
    var product by remember { mutableStateOf<ProductEntity?>(null) }
    var loading by remember { mutableStateOf(barcode.isNotBlank()) }
    var notFound by remember { mutableStateOf(false) }

    var name by remember { mutableStateOf("") }
    var kcal by remember { mutableStateOf("") }
    var protein by remember { mutableStateOf("") }
    var carbs by remember { mutableStateOf("") }
    var fat by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }
    var mealType by remember { mutableStateOf("Lunch") }

    LaunchedEffect(barcode) {
        if (barcode.isNotBlank()) {
            viewModel.fetchProduct(barcode) { result ->
                loading = false
                if (result == null) {
                    notFound = true
                } else {
                    product = result
                    name = result.name
                }
            }
        }
    }

    val quantityValue = quantity.toDoubleOrNull() ?: 0.0
    val kcalPer100 = product?.kcalPer100 ?: kcal.toDoubleOrNull() ?: 0.0
    val proteinPer100 = product?.proteinPer100 ?: protein.toDoubleOrNull() ?: 0.0
    val carbsPer100 = product?.carbsPer100 ?: carbs.toDoubleOrNull() ?: 0.0
    val fatPer100 = product?.fatPer100 ?: fat.toDoubleOrNull() ?: 0.0

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Add food", style = MaterialTheme.typography.headlineSmall)

        if (loading) {
            Text("Looking up product...")
        }

        if (notFound) {
            Text(
                "Product not found in Open Food Facts. Enter the nutrition information manually.",
                color = MaterialTheme.colorScheme.error
            )
        }

        if (product != null) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(product!!.name, style = MaterialTheme.typography.titleMedium)
                    Text(product!!.brand ?: "")
                    Text("Per 100 g:")
                    Text(
                        "%.0f kcal | %.1fg protein | %.1fg carbs | %.1fg fat"
                            .format(
                                product!!.kcalPer100,
                                product!!.proteinPer100,
                                product!!.carbsPer100,
                                product!!.fatPer100
                            )
                    )
                }
            }
        }

        if (product == null) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Food name") },
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = kcal,
                    onValueChange = { kcal = it },
                    label = { Text("kcal / 100g") },
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = protein,
                    onValueChange = { protein = it },
                    label = { Text("Protein g") },
                    modifier = Modifier.weight(1f)
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = carbs,
                    onValueChange = { carbs = it },
                    label = { Text("Carbs g") },
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = fat,
                    onValueChange = { fat = it },
                    label = { Text("Fat g") },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        OutlinedTextField(
            value = quantity,
            onValueChange = { quantity = it },
            label = { Text("Amount eaten (g or ml)") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = mealType,
            onValueChange = { mealType = it },
            label = { Text("Meal") },
            modifier = Modifier.fillMaxWidth()
        )

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Calculated for %.0fg".format(quantityValue))
                Text(
                    "%.0f kcal | %.1fg protein | %.1fg carbs | %.1fg fat"
                        .format(
                            scale(kcalPer100, quantityValue),
                            scale(proteinPer100, quantityValue),
                            scale(carbsPer100, quantityValue),
                            scale(fatPer100, quantityValue)
                        )
                )
            }
        }

        Button(
            onClick = {
                if (quantityValue > 0 && name.isNotBlank()) {
                    viewModel.addEntry(
                        DiaryEntryEntity(
                            date = LocalDate.now().toString(),
                            mealType = mealType.ifBlank { "Other" },
                            barcode = barcode.ifBlank { null },
                            name = name,
                            quantityGrams = quantityValue,
                            kcal = scale(kcalPer100, quantityValue),
                            protein = scale(proteinPer100, quantityValue),
                            carbs = scale(carbsPer100, quantityValue),
                            fat = scale(fatPer100, quantityValue)
                        )
                    )
                    onSaved()
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Save to today")
        }
    }
}
