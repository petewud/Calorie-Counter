package com.example.caloriecounter
import java.time.LocalDate

data class AppWeightForecast(val startDay:Double,val startKg:Double,val kgPerDay:Double,val endDay:Double){
 fun value(day:Double)=startKg+kgPerDay*(day-startDay)
}
fun appWeightForecast(records:List<WeightRecord>,goalDate:String?=null):AppWeightForecast?{
 val sorted=records.filter{it.kg.isFinite()&&it.kg>0&&runCatching{LocalDate.parse(it.date)}.isSuccess}.sortedBy{it.date}.distinctBy{it.date}
 val last=sorted.lastOrNull()?:return null
 val lastDay=LocalDate.parse(last.date).toEpochDay()
 val recent=sorted.filter{LocalDate.parse(it.date).toEpochDay()>=lastDay-28}
 if(recent.size<3||lastDay-LocalDate.parse(recent.first().date).toEpochDay()<7)return null
 val xs=recent.map{(LocalDate.parse(it.date).toEpochDay()-lastDay).toDouble()}
 val meanX=xs.average();val meanKg=recent.map{it.kg}.average()
 val denominator=xs.sumOf{(it-meanX)*(it-meanX)}
 if(denominator<=0)return null
 val slope=recent.indices.sumOf{(xs[it]-meanX)*(recent[it].kg-meanKg)}/denominator
 val target=goalDate?.let{runCatching{LocalDate.parse(it).toEpochDay()}.getOrNull()}
 val requested=if(target!=null&&target>lastDay)(target-lastDay).coerceAtMost(90L).toDouble()else 90.0
 val boundary=when{slope<0->(last.kg-25.0)/(-slope);slope>0->(400.0-last.kg)/slope;else->90.0}
 val days=minOf(requested,boundary)
 if(!slope.isFinite()||days<=0)return null
 return AppWeightForecast(lastDay.toDouble(),last.kg,slope,lastDay.toDouble()+days)
}

fun weightForecast(records:List<WeightRecord>,goalDate:String?=null):AppWeightForecast?=appWeightForecast(records,goalDate)
