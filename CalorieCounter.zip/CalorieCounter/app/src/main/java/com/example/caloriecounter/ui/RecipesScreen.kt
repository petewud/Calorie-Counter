package com.example.caloriecounter.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.caloriecounter.AppViewModel
import kotlinx.coroutines.launch
import java.time.LocalDate

@Composable
fun RecipesScreen(
    viewModel: AppViewModel,
    onNewRecipe: () -> Unit
) {
    val recipes by viewModel.recipes().collectAsStateWithLifecycle(initialValue = emptyList())
    val scope = rememberCoroutineScope()

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = onNewRecipe) {
                Text("+")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Recipes", style = MaterialTheme.typography.headlineSmall)

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(recipes) { recipe ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(recipe.name, style = MaterialTheme.typography.titleMedium)
                            Text(recipe.servings.toString() + " servings")

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        scope.launch {
                                            val ingredients =
                                                viewModel.ingredientsFor(recipe.id)
                                            viewModel.logRecipeServing(
                                                recipe = recipe,
                                                ingredients = ingredients,
                                                date = LocalDate.now().toString(),
                                                mealType = "Meal"
                                            )
                                        }
                                    }
                                ) {
                                    Text("Log 1 serving")
                                }

                                TextButton(onClick = { viewModel.deleteRecipe(recipe) }) {
                                    Text("Delete")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
