@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.example.caloriecounter
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
@Composable
fun Scanner(onCode:(String)->Unit,onCancel:()->Unit){
 val context=LocalContext.current;val owner=LocalLifecycleOwner.current;var allowed by remember{mutableStateOf(ContextCompat.checkSelfPermission(context,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)};var error by remember{mutableStateOf("")};val permission=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){allowed=it};LaunchedEffect(Unit){if(!allowed)permission.launch(Manifest.permission.CAMERA)}
 val executor=remember{Executors.newSingleThreadExecutor()};val scanner=remember{BarcodeScanning.getClient(BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_EAN_13,Barcode.FORMAT_EAN_8,Barcode.FORMAT_UPC_A,Barcode.FORMAT_UPC_E).build())};val done=remember{AtomicBoolean(false)};val alive=remember{AtomicBoolean(true)};var provider by remember{mutableStateOf<ProcessCameraProvider?>(null)};val callback by rememberUpdatedState(onCode)
 DisposableEffect(Unit){onDispose{alive.set(false);provider?.unbindAll();scanner.close();executor.shutdown()}}
 Column(Modifier.fillMaxSize()){
  TextButton(onClick=onCancel){Text("Back to search")}
  if(!allowed){Text("Camera permission is needed to scan.",Modifier.padding(16.dp));Button(onClick={permission.launch(Manifest.permission.CAMERA)}){Text("Grant camera permission")}}
  else AndroidView(modifier=Modifier.weight(1f).fillMaxWidth(),factory={ctx->val view=PreviewView(ctx);val future=ProcessCameraProvider.getInstance(ctx);future.addListener({if(alive.get())try{
   val camera=future.get();provider=camera;val preview=Preview.Builder().build().also{it.setSurfaceProvider(view.surfaceProvider)};val analysis=ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
   analysis.setAnalyzer(executor,object:ImageAnalysis.Analyzer{
    @androidx.annotation.OptIn(ExperimentalGetImage::class)
    override fun analyze(proxy:ImageProxy){val image=proxy.image;if(image==null||done.get()||!alive.get()){proxy.close();return};scanner.process(InputImage.fromMediaImage(image,proxy.imageInfo.rotationDegrees)).addOnSuccessListener{codes->val code=codes.firstNotNullOfOrNull{it.rawValue};if(code!=null&&alive.get()&&done.compareAndSet(false,true))callback(code)}.addOnCompleteListener{proxy.close()}}
   })
   camera.unbindAll();camera.bindToLifecycle(owner,CameraSelector.DEFAULT_BACK_CAMERA,preview,analysis)
  }catch(e:Exception){error=e.message?:"Camera unavailable"}},ContextCompat.getMainExecutor(ctx));view})
  if(error.isNotBlank())Text(error,Modifier.padding(16.dp))
 }
}
