@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.caloriecounter
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

data class RestaurantItem(val id:String,val restaurant:String,val name:String,val category:String,val collected:String,val source:String,val values:List<Double?>)
@Composable
fun RestaurantScreen(onSelect:(Food)->Unit,onCancel:()->Unit){
 val context=LocalContext.current
 val result=remember{runCatching{context.assets.open("restaurants.json").bufferedReader().use{json.fromJson(it.readText(),Array<RestaurantItem>::class.java).toList()}}}
 val rows=result.getOrDefault(emptyList())
 var query by remember{mutableStateOf("")}
 Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
  Text("Restaurants",style=MaterialTheme.typography.headlineSmall)
  TextButton(onClick=onCancel){Text("Back")}
  OutlinedTextField(query,{query=it},label={Text("Restaurant or menu item")},modifier=Modifier.fillMaxWidth())
  Text("MenuTracker collection, 24 Oct 2026. Selected records only, not complete menus. Portions and availability may change; check restaurant information. Missing nutrients stay unknown.",style=MaterialTheme.typography.bodySmall)
  if(result.isFailure)Text("Restaurant data unavailable.",color=MaterialTheme.colorScheme.error)
  val words=query.lowercase().split(" ").filter{it.isNotBlank()}
  val shown=rows.filter{r->words.all{w->("${r.restaurant} ${r.name} ${r.category}").lowercase().contains(w)}}
  Text("${shown.size} items")
  LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(6.dp)){
   items(shown,key={it.id}){r->OutlinedButton(onClick={onSelect(Food("${r.restaurant} — ${r.name}","menutracker:${r.id}",r.restaurant,Nutrients(r.values),"menu portion",100.0))},modifier=Modifier.fillMaxWidth()){
    Column(Modifier.fillMaxWidth()){Text(r.name);Text(r.restaurant+if(r.category.isBlank())""else " · ${r.category}");Text("${numberText(r.values[0],0)}kcal per listed portion");Text("Collected ${r.collected}",style=MaterialTheme.typography.labelSmall)}
   }}
  }
 }
}
@Composable
fun RestaurantPortionForm(initial:Ingredient,onCancel:()->Unit,onReplace:()->Unit,onSave:(Ingredient)->Unit){
 var quantity by remember{mutableStateOf(initial.amount.toString())}
 val q=quantity.toDoubleOrNull()?.takeIf{it.isFinite()&&it>0}
 Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
  Text(initial.food.name,style=MaterialTheme.typography.titleLarge)
  Text("Nutrition is per listed menu portion, not per 100g. Extras and meal combinations are not included unless explicitly listed. Check the restaurant's published values.")
  NumericField(quantity,{quantity=it},"Number of menu portions")
  NutritionText(initial.food.nutrients*(q?:0.0))
  Button(enabled=q!=null,onClick={onSave(initial.copy(amount=q!!,unit="menu portion",unitGrams=100.0))}){Text("Save")}
  OutlinedButton(onClick=onReplace){Text("Choose another food")}
  TextButton(onClick=onCancel){Text("Cancel")}
 }
}
