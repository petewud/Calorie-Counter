package com.example.caloriecounter.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF00696E),
    secondary = Color(0xFF4A6365),
    tertiary = Color(0xFF526100)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF4CDADD),
    secondary = Color(0xFFB1CCCE),
    tertiary = Color(0xFFC1CA28)
)

@Composable
fun CalorieCounterTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
