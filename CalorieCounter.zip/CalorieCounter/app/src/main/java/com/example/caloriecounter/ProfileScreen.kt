@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example.caloriecounter
import android.app.DatePickerDialog
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.time.LocalDate
@Composable
fun ProfileScreen(initial:Profile,onboarding:Boolean,store:Store,onSave:(Profile)->Unit){
 val context=LocalContext.current
 var sex by remember{mutableStateOf(if(onboarding)""else initial.sex)};var age by remember{mutableStateOf(if(onboarding)""else initial.age.toString())}
 var height by remember{mutableStateOf(if(onboarding)""else initial.height.toString())};var weight by remember{mutableStateOf(if(onboarding)""else initial.weight.toString())}
 var targetWeight by remember{mutableStateOf(initial.targetWeight?.toString().orEmpty())};var goalDate by remember{mutableStateOf(initial.targetWeightDate)}
 var activity by remember{mutableDoubleStateOf(initial.activity)};var uk by remember{mutableStateOf(initial.ukFirst)};var estimate by remember{mutableStateOf(onboarding)}
 var auto by remember{mutableStateOf(initial.autoCalorieTarget)};var eligible by remember{mutableStateOf(initial.autoGoalEligible)}
 val targets=remember{mutableStateListOf<String>().apply{addAll(initial.targets.map{it.toString()})}};var message by remember{mutableStateOf("")}
 val a=age.toIntOrNull();val h=height.toDoubleOrNull();val w=weight.toDoubleOrNull();val goal=targetWeight.toDoubleOrNull()
 val valid=sex in listOf("Female","Male")&&a!=null&&a in 18..120&&h!=null&&h.isFinite()&&h in 100.0..250.0&&w!=null&&w.isFinite()&&w in 25.0..400.0
 val goalValid=if(targetWeight.isBlank())!onboarding else goal!=null&&goal.isFinite()&&goal in 25.0..400.0
 val kcal=if(valid)estimateCalories(sex,a!!,h!!,w!!,activity)else null
 val numbers=targets.mapIndexed{i,t->if(i==0&&auto)initial.targets[0]else if(i==0&&estimate)kcal else t.toDoubleOrNull()}
 val numbersValid=numbers.all{it!=null&&it.isFinite()&&it>0}
 val candidate=Profile(true,sex,a?:30,h?:170.0,w?:70.0,activity,numbers.map{it?:2000.0},uk,goal,goalDate,auto,eligible)
 val plan=calorieGoalEstimate(candidate)
 val export=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")){uri->if(uri!=null)runCatching{context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use{it.write(store.exportBackup())}?:error("Cannot open backup")}.onSuccess{message="Backup saved."}.onFailure{message="Backup failed: ${it.message}"}}
 val importer=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null)runCatching{val raw=context.contentResolver.openInputStream(uri)?.bufferedReader()?.use{it.readText()}?:error("Cannot read backup");store.importBackup(raw)}.onSuccess{onSave(store.profile())}.onFailure{message="Import failed: ${it.message}"}}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).imePadding().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  Text(if(onboarding)"Set up your profile"else "Settings",style=MaterialTheme.typography.headlineMedium)
  Text("For adults 18+. Energy estimates are not a prescribed diet. Not suitable for pregnancy, breastfeeding, eating disorders or conditions/treatments requiring individual dietary advice.")
  Text("Sex coefficient used by the energy equation")
  Row{FilterChip(selected=sex=="Female",onClick={sex="Female"},label={Text("Female")});Spacer(Modifier.width(8.dp));FilterChip(selected=sex=="Male",onClick={sex="Male"},label={Text("Male")})}
  NumericField(age,{age=it},"Age (years, 18+)");NumericField(height,{height=it},"Height (cm)");NumericField(weight,{weight=it},"Weight (kg)");NumericField(targetWeight,{targetWeight=it},"Target weight (kg)")
  Row{OutlinedButton(onClick={val d=goalDate?.let{runCatching{LocalDate.parse(it)}.getOrNull()}?:LocalDate.now().plusDays(90);DatePickerDialog(context,{_,y,m,day->goalDate=LocalDate.of(y,m+1,day).toString()},d.year,d.monthValue-1,d.dayOfMonth).apply{datePicker.minDate=LocalDate.now().plusDays(1).atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()}.show()}){Text(goalDate?.let{"Target date: $it"}?:"Target date (optional)")};if(goalDate!=null)TextButton(onClick={goalDate=null;auto=false}){Text("Clear")}}
  Text("Activity")
  listOf("Sedentary" to 1.2,"Lightly active" to 1.375,"Moderately active" to 1.55,"Very active" to 1.725).forEach{(label,value)->Row{RadioButton(selected=activity==value,onClick={activity=value});TextButton(onClick={activity=value}){Text(label)}}}
  Text("Estimated maintenance: ${numberText(kcal,0)}kcal/day")
  Row{Switch(checked=auto,enabled=auto||(valid&&goalValid&&goal!=null&&goalDate!=null),onCheckedChange={auto=it;if(it)estimate=false});Text("Automatically estimate calories for target weight/date",Modifier.weight(1f).padding(8.dp))}
  if(auto){
   Row{Checkbox(checked=eligible,onCheckedChange={eligible=it});Text("I am 18+, not pregnant or breastfeeding, and do not need a medically supervised or eating-disorder nutrition plan.",Modifier.weight(1f).padding(top=8.dp))}
   Text("Estimated daily target: ${numberText(plan.calories,0)}kcal",style=MaterialTheme.typography.titleMedium)
   Text(plan.message)
   Text("Uses estimated maintenance plus a rough 7,700kcal/kg energy adjustment over the remaining days. Not a guarantee of reaching the target. Limits: at most a 500kcal/day reduction or 300kcal/day increase; minimum 1,200kcal/day for the female coefficient or 1,500 for male. These limits do not establish an individually safe intake. Estimates pause after the target date or for an underweight current/target BMI. Review with a qualified professional if appropriate.",style=MaterialTheme.typography.bodySmall)
  }
  Row{Switch(checked=estimate,enabled=!auto,onCheckedChange={estimate=it});Text("Use maintenance estimate as calorie target",Modifier.weight(1f).padding(8.dp))}
  Text("Daily targets and references",style=MaterialTheme.typography.titleLarge)
  nutrientNames.forEachIndexed{i,label->if(i==0&&auto)Text("Calorie target: ${numberText(plan.calories,0)}kcal")else if(i==0&&estimate)Text("Calorie target: ${numberText(kcal,0)}kcal")else NumericField(targets[i],{targets[i]=it},"$label (${nutrientUnits[i]}/day)")}
  Text("Other starting values are general label references and a fibre goal, not personalised RDAs. Fat, saturated fat and salt are limits. Total sugars is not a free-sugars allowance.",style=MaterialTheme.typography.bodySmall)
  Row{Switch(checked=uk,onCheckedChange={uk=it});Text("Prioritise UK-labelled results",Modifier.padding(8.dp))}
  val dateValid=goalDate==null||(goal!=null&&runCatching{LocalDate.parse(goalDate!!)}.isSuccess)
  Button(enabled=valid&&goalValid&&numbersValid&&dateValid&&(!auto||plan.calories!=null),onClick={onSave(candidate)},modifier=Modifier.fillMaxWidth()){Text("Save settings")}
  if(!onboarding){HorizontalDivider();Button(onClick={export.launch("calorie-counter-backup.json")}){Text("Export diary, recipes, weights and profile")};OutlinedButton(onClick={importer.launch(arrayOf("application/json","text/plain","application/octet-stream"))}){Text("Import backup (merge)")};Text("Import adds diary/recipe records; existing weight dates are skipped.",style=MaterialTheme.typography.bodySmall)}
  Text(message)
  Text("Food data: Open Food Facts (ODbL) and collected MenuTracker restaurant records. Verify source nutrition and portion sizes. Data is local except food searches/barcode requests.",style=MaterialTheme.typography.bodySmall)
 }
}
