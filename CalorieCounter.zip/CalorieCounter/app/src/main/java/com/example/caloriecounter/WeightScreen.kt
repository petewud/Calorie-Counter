@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.example.caloriecounter
import android.app.DatePickerDialog
import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.math.hypot
@Composable
fun WeightScreen(records:List<WeightRecord>,profile:Profile,onSave:(WeightRecord)->Unit,onDelete:(Long)->Unit,onTarget:(Double)->Unit){
 val context=LocalContext.current;var amount by androidx.compose.runtime.saveable.rememberSaveable{mutableStateOf("")};var dateText by androidx.compose.runtime.saveable.rememberSaveable{mutableStateOf(LocalDate.now().toString())};var target by remember(profile.targetWeight){mutableStateOf(profile.targetWeight?.toString().orEmpty())};var selected by remember{mutableStateOf<WeightRecord?>(null)};var replace by remember{mutableStateOf<WeightRecord?>(null)};var message by remember{mutableStateOf("")}
 val current=records.maxByOrNull{it.date};val q=amount.toDoubleOrNull()?.takeIf{it.isFinite()&&it in 25.0..400.0};val t=target.toDoubleOrNull()?.takeIf{it.isFinite()&&it in 25.0..400.0}
 fun save(r:WeightRecord){runCatching{onSave(r)}.onSuccess{amount="";message="Measurement saved."}.onFailure{message=it.message?:"Cannot save measurement"}}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).imePadding().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  Text("Weight",style=MaterialTheme.typography.headlineMedium)
  Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text(if(current==null)"Profile weight: ${numberText(profile.weight)}kg"else "Current weight: ${numberText(current.kg)}kg",style=MaterialTheme.typography.titleLarge);Text(if(current==null)"No dated measurements yet. Add your first measurement below."else "Latest measurement: ${current.date}");if(records.size>=2){val change=current!!.kg-records.first().kg;Text("Change since first measurement: ${if(change>0)"+"else ""}${numberText(change)}kg")};profile.targetWeight?.let{Text("Target: ${numberText(it)}kg")}}}
  NumericField(amount,{amount=it},"Weight (kg)")
  OutlinedButton(onClick={val d=LocalDate.parse(dateText);DatePickerDialog(context,{_,y,m,day->dateText=LocalDate.of(y,m+1,day).toString()},d.year,d.monthValue-1,d.dayOfMonth).apply{datePicker.maxDate=System.currentTimeMillis()}.show()}){Text("Measurement date: $dateText")}
  Button(enabled=q!=null,onClick={val r=WeightRecord(date=dateText,kg=q!!);val existing=records.firstOrNull{it.date==dateText};if(existing==null)save(r)else replace=r.copy(id=existing.id)}){Text("Save weight")};Text(message)
  NumericField(target,{target=it},"Target weight (kg)");OutlinedButton(enabled=t!=null,onClick={onTarget(t!!);message="Target updated."}){Text("Save target weight")}
  Text("Progress",style=MaterialTheme.typography.titleLarge);Text("Pinch to zoom, drag to move, and tap a point to view or edit it. One measurement is stored per date.",style=MaterialTheme.typography.bodySmall);WeightChart(records,profile.targetWeight){selected=it}
  Text("Weight changes do not automatically change your calorie target. Review the calorie estimate in Settings if needed.",style=MaterialTheme.typography.bodySmall)
  if(records.isNotEmpty()){Text("Measurements (tap to edit)",style=MaterialTheme.typography.titleMedium);records.asReversed().forEach{r->TextButton(onClick={selected=r},modifier=Modifier.fillMaxWidth()){Text("${r.date} — ${numberText(r.kg)}kg")}}}
 }
 replace?.let{r->AlertDialog(onDismissRequest={replace=null},title={Text("Replace this day's measurement?")},text={Text("Replace the measurement for ${r.date} with ${numberText(r.kg)}kg?")},confirmButton={TextButton(onClick={save(r);replace=null}){Text("Replace")}},dismissButton={TextButton(onClick={replace=null}){Text("Cancel")}})}
 selected?.let{r->WeightEditDialog(r,records,onDismiss={selected=null},onSave={onSave(it);selected=null},onDelete={onDelete(r.id);selected=null})}
}
@Composable
private fun WeightEditDialog(record:WeightRecord,records:List<WeightRecord>,onDismiss:()->Unit,onSave:(WeightRecord)->Unit,onDelete:()->Unit){
 val context=LocalContext.current;var kg by remember(record.id){mutableStateOf(record.kg.toString())};var date by remember(record.id){mutableStateOf(record.date)};var error by remember{mutableStateOf("")};var deleting by remember{mutableStateOf(false)};val value=kg.toDoubleOrNull()?.takeIf{it.isFinite()&&it in 25.0..400.0}
 AlertDialog(onDismissRequest=onDismiss,title={Text("Weight measurement")},text={Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
  NumericField(kg,{kg=it},"Weight (kg)");OutlinedButton(onClick={val d=LocalDate.parse(date);DatePickerDialog(context,{_,y,m,day->date=LocalDate.of(y,m+1,day).toString()},d.year,d.monthValue-1,d.dayOfMonth).apply{datePicker.maxDate=System.currentTimeMillis()}.show()}){Text(date)};Text(error,color=MaterialTheme.colorScheme.error)
  if(deleting){Text("Delete this measurement permanently?");TextButton(onClick=onDelete){Text("Confirm deletion")}}else TextButton(onClick={deleting=true}){Text("Delete measurement")}
 }},confirmButton={TextButton(enabled=value!=null,onClick={if(records.any{it.id!=record.id&&it.date==date})error="Another measurement already uses this date."else runCatching{onSave(record.copy(date=date,kg=value!!))}.onFailure{error=it.message?:"Cannot save measurement"}}){Text("Save")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}
@Composable
private fun WeightChart(records:List<WeightRecord>,target:Double?,onSelect:(WeightRecord)->Unit){
 var zoom by remember{mutableFloatStateOf(1f)};var pan by remember{mutableStateOf(Offset.Zero)};var canvasSize by remember{mutableStateOf(Size.Zero)};val colors=MaterialTheme.colorScheme;val points=records.sortedBy{it.date}
 val first=points.firstOrNull()?.let{LocalDate.parse(it.date).toEpochDay().toDouble()}?:LocalDate.now().toEpochDay().toDouble();val last=points.lastOrNull()?.let{LocalDate.parse(it.date).toEpochDay().toDouble()}?:first;val xMin=first-1.0;val xMax=if(last<=first)first+1.0 else last+1.0
 val ys=points.map{it.kg}+listOfNotNull(target);val lo=(ys.minOrNull()?:60.0)-2.0;val hi=(ys.maxOrNull()?:80.0)+2.0
 fun project(r:WeightRecord,size:Size):Offset{val left=52f;val top=20f;val width=(size.width-left-18).coerceAtLeast(1f);val height=(size.height-top-42).coerceAtLeast(1f);val x=left+((LocalDate.parse(r.date).toEpochDay()-xMin)/(xMax-xMin)*width).toFloat();val y=top+((hi-r.kg)/(hi-lo)*height).toFloat();return Offset(x,y)*zoom+pan}
 Column{
  TextButton(onClick={zoom=1f;pan=Offset.Zero}){Text("Reset graph")};if(records.isEmpty())Text("Add a measurement to start the graph.")
  Surface(tonalElevation=2.dp,shape=MaterialTheme.shapes.medium){
   Canvas(Modifier.fillMaxWidth().height(260.dp)
    .pointerInput(points,target){detectTransformGestures{centroid,change,factor,_->val next=(zoom*factor).coerceIn(1f,12f);val moved=centroid-(centroid-pan)*(next/zoom)+change;zoom=next;val maxX=canvasSize.width*zoom;val maxY=canvasSize.height*zoom;pan=Offset(moved.x.coerceIn(-maxX,maxX),moved.y.coerceIn(-maxY,maxY))}}
    .pointerInput(points,target,zoom,pan){detectTapGestures{tap->points.minByOrNull{r->val p=project(r,canvasSize);hypot((p.x-tap.x).toDouble(),(p.y-tap.y).toDouble())}?.let{r->val p=project(r,canvasSize);if((p-tap).getDistance()<28.dp.toPx())onSelect(r)}}}){
    canvasSize=size;val left=52f;val top=20f;val width=(size.width-left-18).coerceAtLeast(1f);val height=(size.height-top-42).coerceAtLeast(1f);val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=colors.onSurface.toArgb();textSize=11.dp.toPx()}
    for(tick in 0..4){val y=top+height*tick/4;drawLine(colors.outlineVariant,Offset(left,y),Offset(left+width,y));val baseY=(y-pan.y)/zoom;val kg=hi-((baseY-top)/height)*(hi-lo);drawContext.canvas.nativeCanvas.drawText(numberText(kg),2f,y+4f,paint)}
    drawContext.canvas.nativeCanvas.drawText("kg",2f,12f,paint)
    clipRect(left,top,left+width,top+height){
     target?.let{goal->val y=(top+((hi-goal)/(hi-lo)*height).toFloat())*zoom+pan.y;drawLine(colors.tertiary,Offset(left,y),Offset(left+width,y),2.dp.toPx(),pathEffect=androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(12f,8f)))}
     points.zipWithNext().forEach{(a,b)->drawLine(colors.primary,project(a,size),project(b,size),2.dp.toPx())};points.forEach{r->val p=project(r,size);drawCircle(colors.primary,5.dp.toPx(),p);drawCircle(colors.surface,2.dp.toPx(),p)}
    }
    val formatter=DateTimeFormatter.ofPattern("d MMM yy")
    fun dateAt(x:Float):String{val base=(x-pan.x)/zoom;return LocalDate.ofEpochDay((xMin+(base-left)/width*(xMax-xMin)).toLong()).format(formatter)}
    drawContext.canvas.nativeCanvas.drawText(dateAt(left),left,size.height-8f,paint);paint.textAlign=Paint.Align.RIGHT;drawContext.canvas.nativeCanvas.drawText(dateAt(left+width),left+width,size.height-8f,paint)
   }
  }
  if(target!=null)Text("Dashed line: target ${numberText(target)}kg",style=MaterialTheme.typography.bodySmall)
 }
}
