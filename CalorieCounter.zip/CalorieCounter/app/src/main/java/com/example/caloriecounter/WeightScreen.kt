@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.example.caloriecounter
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.onSizeChanged
import android.app.DatePickerDialog
import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.math.hypot
@Composable
fun WeightScreen(records:List<WeightRecord>,profile:Profile,onSave:(WeightRecord)->Unit,onDelete:(Long)->Unit){
 val context=LocalContext.current;var amount by androidx.compose.runtime.saveable.rememberSaveable{mutableStateOf("")};var dateText by androidx.compose.runtime.saveable.rememberSaveable{mutableStateOf(LocalDate.now().toString())};var selected by remember{mutableStateOf<WeightRecord?>(null)};var replace by remember{mutableStateOf<WeightRecord?>(null)};var message by remember{mutableStateOf("")};val current=records.maxByOrNull{it.date};val q=amount.toDoubleOrNull()?.takeIf{it.isFinite()&&it in 25.0..400.0}
 fun save(r:WeightRecord){runCatching{onSave(r)}.onSuccess{amount="";message="Saved"}.onFailure{message=it.message?:"Cannot save measurement"}}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).imePadding().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  val lost=if(current!=null)records.minByOrNull{it.date}!!.kg-current.kg else 0.0
  Text("Current weight: ${numberText(current?.kg?:profile.weight)}kg",style=MaterialTheme.typography.titleLarge)
  Text(if(lost>=0)"Weight lost: ${numberText(lost)}kg"else "Weight gained: ${numberText(-lost)}kg",style=MaterialTheme.typography.titleMedium)
  NumericField(amount,{amount=it},"Weight (kg)")
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
   OutlinedButton(modifier=Modifier.weight(1f),onClick={val d=LocalDate.parse(dateText);DatePickerDialog(context,{_,y,m,day->dateText=LocalDate.of(y,m+1,day).toString()},d.year,d.monthValue-1,d.dayOfMonth).apply{datePicker.maxDate=System.currentTimeMillis()}.show()}){Text(dateText)}
   Button(enabled=q!=null,onClick={val r=WeightRecord(date=dateText,kg=q!!);val existing=records.firstOrNull{it.date==dateText};if(existing==null)save(r)else replace=r.copy(id=existing.id)}){Text("Save weight")}
  }
  if(message.isNotBlank())Text(message)
  Text("Progress",style=MaterialTheme.typography.titleLarge)
  WeightChart(records,profile.targetWeight,profile.targetWeightDate){selected=it}
  if(records.isNotEmpty()){Text("Measurements",style=MaterialTheme.typography.titleMedium);records.asReversed().forEach{r->TextButton(onClick={selected=r},modifier=Modifier.fillMaxWidth()){Text("${r.date} — ${numberText(r.kg)}kg")}}}
 }
 replace?.let{r->AlertDialog(onDismissRequest={replace=null},title={Text("Replace this day's measurement?")},text={Text("Replace ${r.date} with ${numberText(r.kg)}kg?")},confirmButton={TextButton(onClick={save(r);replace=null}){Text("Replace")}},dismissButton={TextButton(onClick={replace=null}){Text("Cancel")}})}
 selected?.let{r->WeightEditDialog(r,records,onDismiss={selected=null},onSave={onSave(it);selected=null},onDelete={onDelete(r.id);selected=null})}
}
@Composable
private fun WeightEditDialog(record:WeightRecord,records:List<WeightRecord>,onDismiss:()->Unit,onSave:(WeightRecord)->Unit,onDelete:()->Unit){
 val context=LocalContext.current;var kg by remember(record.id){mutableStateOf(record.kg.toString())};var date by remember(record.id){mutableStateOf(record.date)};var error by remember{mutableStateOf("")};var deleting by remember{mutableStateOf(false)};val value=kg.toDoubleOrNull()?.takeIf{it.isFinite()&&it in 25.0..400.0}
 AlertDialog(onDismissRequest=onDismiss,title={Text("Weight measurement")},text={Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
  NumericField(kg,{kg=it},"Weight (kg)");OutlinedButton(onClick={val d=LocalDate.parse(date);DatePickerDialog(context,{_,y,m,day->date=LocalDate.of(y,m+1,day).toString()},d.year,d.monthValue-1,d.dayOfMonth).apply{datePicker.maxDate=System.currentTimeMillis()}.show()}){Text(date)};Text(error,color=MaterialTheme.colorScheme.error)
  if(deleting){Text("Delete this measurement permanently?");TextButton(onClick=onDelete){Text("Confirm deletion")}}else TextButton(onClick={deleting=true}){Text("Delete measurement")}
 }},confirmButton={TextButton(enabled=value!=null,onClick={if(records.any{it.id!=record.id&&it.date==date})error="Another measurement already uses this date."else runCatching{onSave(record.copy(date=date,kg=value!!))}.onFailure{error=it.message?:"Cannot save measurement"}}){Text("Save")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}
@Composable
private fun WeightChart(records:List<WeightRecord>,target:Double?,onSelect:(WeightRecord)->Unit){
 WeightChart(records,target,null,onSelect)
}
@Composable
private fun WeightChart(records:List<WeightRecord>,target:Double?,targetDate:String?,onSelect:(WeightRecord)->Unit){
 var zoom by remember{mutableFloatStateOf(1f)}
 var pan by remember{mutableStateOf(Offset.Zero)}
 var canvasSize by remember{mutableStateOf(Size.Zero)}
 val density=androidx.compose.ui.platform.LocalDensity.current
 val colors=MaterialTheme.colorScheme
 val points=records.filter{it.kg.isFinite()&&runCatching{LocalDate.parse(it.date)}.isSuccess}.sortedBy{it.date}
 val trend=remember(records,targetDate){appWeightForecast(records,targetDate)}
 val first=points.firstOrNull()?.let{LocalDate.parse(it.date).toEpochDay().toDouble()}?:LocalDate.now().toEpochDay().toDouble()
 val last=points.lastOrNull()?.let{LocalDate.parse(it.date).toEpochDay().toDouble()}?:first
 val goalWeight=target?.takeIf{it.isFinite()}
 val goalDay=targetDate?.let{runCatching{LocalDate.parse(it).toEpochDay().toDouble()}.getOrNull()}?.takeIf{it>first&&goalWeight!=null&&points.isNotEmpty()}
 val end=maxOf(last,goalDay?:last,trend?.endDay?:last)
 val ys=(points.map{it.kg}+listOfNotNull(if(goalDay!=null)goalWeight else null,trend?.let{it.value(it.endDay)})).filter{it.isFinite()}
 val low=ys.minOrNull()?:60.0;val high=ys.maxOrNull()?:80.0
 val padX=maxOf(1.0,maxOf(end-first,1.0)*.06)
 val padY=maxOf(.7,maxOf(high-low,1.0)*.12)
 val minX=first-padX;val maxX=end+padX;val minY=low-padY;val maxY=high+padY
 val goalColor=Color(0xFF2EAB58);val forecastColor=Color(0xFFED9643)
 val labelSize=with(density){11.sp.toPx()};val outer=with(density){10.dp.toPx()};val gap=with(density){8.dp.toPx()}
 val paint=remember(colors.onSurface,labelSize){Paint(Paint.ANTI_ALIAS_FLAG).apply{color=colors.onSurface.toArgb();textSize=labelSize}}
 fun plotBox(s:Size):androidx.compose.ui.geometry.Rect{
  val labelWidth=listOf(minY,maxY,(minY+maxY)/2).maxOf{paint.measureText(numberText(it))}
  val left=outer+labelWidth+gap;val top=outer+with(density){8.dp.toPx()}
  return androidx.compose.ui.geometry.Rect(left,top,maxOf(left+1f,s.width-outer),maxOf(top+1f,s.height-outer-with(density){24.dp.toPx()}))
 }
 fun project(day:Double,kg:Double,s:Size):Offset{
  val b=plotBox(s);val x=((day-minX)/(maxX-minX)-.5).toFloat();val y=((maxY-kg)/(maxY-minY)-.5).toFloat()
  return b.center+Offset(x*b.width*zoom,y*b.height*zoom)+pan
 }
 fun point(r:WeightRecord,s:Size)=project(LocalDate.parse(r.date).toEpochDay().toDouble(),r.kg,s)
 Column{
  TextButton(onClick={zoom=1f;pan=Offset.Zero}){Text("Reset graph")}
  Surface(tonalElevation=2.dp,shape=MaterialTheme.shapes.medium){
   Canvas(Modifier.fillMaxWidth().height(280.dp)
    .onSizeChanged{canvasSize=Size(it.width.toFloat(),it.height.toFloat())}
    .pointerInput(points,target,targetDate,density.density,density.fontScale){
     detectTransformGestures{centroid,change,factor,_->
      val b=plotBox(canvasSize);val next=(zoom*factor).coerceIn(1f,16f)
      val pivot=Offset(centroid.x.coerceIn(b.left,b.right),centroid.y.coerceIn(b.top,b.bottom))-b.center
      val moved=(pan-pivot)*(next/zoom)+pivot+change
      val maxPanX=b.width*(next-1f)/2f;val maxPanY=b.height*(next-1f)/2f
      zoom=next;pan=Offset(moved.x.coerceIn(-maxPanX,maxPanX),moved.y.coerceIn(-maxPanY,maxPanY))
     }
    }
    .pointerInput(points,target,targetDate,zoom,pan){
     detectTapGestures{tap->
      val b=plotBox(canvasSize)
      if(b.contains(tap))points.minByOrNull{r->val p=point(r,canvasSize);hypot((p.x-tap.x).toDouble(),(p.y-tap.y).toDouble())}?.let{r->
       if((point(r,canvasSize)-tap).getDistance()<with(density){28.dp.toPx()})onSelect(r)
      }
     }
    }){
    val b=plotBox(size);val metrics=paint.fontMetrics;paint.textAlign=Paint.Align.RIGHT
    for(tick in 0..4){
     val y=b.top+b.height*tick/4f;drawLine(colors.outlineVariant,Offset(b.left,y),Offset(b.right,y))
     val normalized=.5+((y-b.center.y-pan.y)/(b.height*zoom)).toDouble()
     val kg=maxY-normalized*(maxY-minY);val baseline=y-(metrics.ascent+metrics.descent)/2f
     drawContext.canvas.nativeCanvas.drawText(numberText(kg),b.left-gap,baseline,paint)
    }
    clipRect(b.left,b.top,b.right,b.bottom){
     if(goalDay!=null&&goalWeight!=null&&points.isNotEmpty())drawLine(goalColor,project(first,points.first().kg,size),project(goalDay,goalWeight,size),2.dp.toPx())
     trend?.let{f->drawLine(forecastColor,project(f.startDay,f.startKg,size),project(f.endDay,f.value(f.endDay),size),2.dp.toPx(),pathEffect=androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(12f,8f)))}
     points.zipWithNext().forEach{(a,bp)->drawLine(colors.primary,point(a,size),point(bp,size),2.dp.toPx())}
     points.forEach{r->val p=point(r,size);drawCircle(colors.primary,5.dp.toPx(),p);drawCircle(colors.surface,2.dp.toPx(),p)}
    }
    val formatter=DateTimeFormatter.ofPattern("d MMM yy")
    fun dateAt(x:Float):String{
     val normalized=.5+((x-b.center.x-pan.x)/(b.width*zoom)).toDouble()
     return LocalDate.ofEpochDay((minX+normalized*(maxX-minX)).toLong()).format(formatter)
    }
    val baseline=size.height-outer-metrics.descent
    paint.textAlign=Paint.Align.LEFT;drawContext.canvas.nativeCanvas.drawText(dateAt(b.left),b.left,baseline,paint)
    paint.textAlign=Paint.Align.RIGHT;drawContext.canvas.nativeCanvas.drawText(dateAt(b.right),b.right,baseline,paint)
   }
  }
  if(goalDay!=null)Text("Green: goal",color=goalColor,style=MaterialTheme.typography.bodySmall)
  if(trend!=null)Text("Orange dashed: estimated trend",color=forecastColor,style=MaterialTheme.typography.bodySmall)
  else if(points.isNotEmpty())Text("Prediction needs 3 measurements spanning 7 days.",style=MaterialTheme.typography.bodySmall)
 }
}

