package com.example.caloriecounter
import org.junit.Assert.*
import org.junit.Test
class FavouritesAndPortionTest{
 private fun item()=Ingredient(Food("Manual oats",nutrients=Nutrients(listOf(400.0,20.0,40.0,12.0,5.0,6.0,8.0,1.0))),70.0)
 @Test fun recipePortionDividesTotals(){val r=Recipe(name="Meal",servings=4,ingredients=listOf(item().copy(amount=100.0)));val e=Entry(date="2026-10-25",food=r.servingFood(),amount=1.0,unit="portion",unitGrams=100.0);assertEquals(100.0,e.total()[0]!!,0.00001);assertEquals(5.0,e.total()[1]!!,0.00001)}
 @Test fun singlePortionEqualsWholeRecipe(){val r=Recipe(name="Porridge",ingredients=listOf(item()));val e=Entry(date="2026-10-25",food=r.servingFood(),amount=1.0,unit="portion",unitGrams=100.0);assertEquals(280.0,e.total()[0]!!,0.00001)}
 @Test fun manualFoodCanBeFavourite(){assertTrue(item().food.barcode.isBlank());assertTrue(validFavourite(item()));assertEquals(1,toggledFavourites(emptyList(),item()).size)}
 @Test fun defaultOffAndToggleOnOff(){val original=emptyList<Favourite>();assertFalse(original.any{it.id==favouriteId(item())});val on=toggledFavourites(original,item());assertTrue(on.any{it.id==favouriteId(item())});assertTrue(toggledFavourites(on,item()).isEmpty())}
 @Test fun sameFoodDifferentAmountSharesStar(){val on=toggledFavourites(emptyList(),item());assertTrue(toggledFavourites(on,item().copy(amount=200.0)).isEmpty())}
 @Test fun otherFavouriteIsRetained(){val other=item().copy(food=item().food.copy(name="Milk"));val both=toggledFavourites(toggledFavourites(emptyList(),item()),other);val remaining=toggledFavourites(both,item());assertEquals(1,remaining.size);assertEquals("Milk",remaining[0].ingredient.food.name)}
 @Test fun favouriteRetainsPreferredAmount(){val i=item();val f=Favourite(favouriteId(i),i);val saved=json.fromJson(json.toJson(f),Favourite::class.java);assertEquals(70.0,saved.ingredient.amount,0.0);assertEquals(280.0,saved.ingredient.total()[0]!!,0.00001)}
 @Test fun invalidAmountRejected(){assertFalse(validFavourite(item().copy(amount=0.0)));assertFalse(validFavourite(item().copy(amount=Double.NaN)))}
 @Test fun togglingDoesNotChangeDiarySnapshot(){val i=item();val before=json.toJson(i);val on=toggledFavourites(emptyList(),i);toggledFavourites(on,i);assertEquals(before,json.toJson(i))}
}
