package com.example.caloriecounter
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate
class ForecastRepairTest{
 private fun point(days:Int,kg:Double)=WeightRecord(date=LocalDate.of(2026,1,1).plusDays(days.toLong()).toString(),kg=kg)
 @Test fun helperHasGraphFields(){val f=appWeightForecast(listOf(point(0,80.0),point(7,79.3),point(14,78.6)),null)!!;assertEquals(78.6,f.startKg,0.00001);assertEquals(-0.1,f.kgPerDay,0.00001);assertTrue(f.endDay>f.startDay);assertEquals(77.9,f.value(f.startDay+7),0.00001)}
 @Test fun tooFewPoints(){assertNull(appWeightForecast(listOf(point(0,80.0),point(14,79.0)),null))}
 @Test fun tooShortSpan(){assertNull(appWeightForecast(listOf(point(0,80.0),point(1,79.9),point(2,79.8)),null))}
 @Test fun irregularSpacing(){val f=appWeightForecast(listOf(point(0,80.0),point(3,79.7),point(14,78.6)),null)!!;assertEquals(-0.1,f.kgPerDay,0.00001)}
 @Test fun gain(){assertTrue(appWeightForecast(listOf(point(0,70.0),point(7,70.7),point(14,71.4)),null)!!.kgPerDay>0)}
 @Test fun oldOrBadRecordsDoNotContaminateTrend(){val f=appWeightForecast(listOf(point(-100,150.0),WeightRecord(date="invalid",kg=70.0),point(0,80.0),point(7,79.3),point(14,78.6)),null)!!;assertEquals(-0.1,f.kgPerDay,0.00001)}
}
