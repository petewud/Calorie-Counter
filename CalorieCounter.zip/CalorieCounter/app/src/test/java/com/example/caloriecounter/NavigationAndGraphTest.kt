package com.example.caloriecounter
import org.junit.Assert.*
import org.junit.Test
class NavigationAndGraphTest{
 @Test fun scanReturnsToAdd(){assertEquals("Search",foodFlowBackDestination("Scan","Home","Home"))}
 @Test fun manualFoodReturnsToAdd(){assertEquals("Search",foodFlowBackDestination("Food","Search","Home"))}
 @Test fun restaurantReturnsToAdd(){assertEquals("Search",foodFlowBackDestination("Restaurants","Home","Home"))}
 @Test fun diaryEditingReturnsToDiary(){assertEquals("History",foodFlowBackDestination("Food","History","Home"))}
 @Test fun replacementCancelReturnsToFood(){assertEquals("Food",foodFlowBackDestination("Search","History","Food"))}
 @Test fun recipeIngredientAddReturnsToRecipe(){assertEquals("Recipe",foodFlowBackDestination("Search","Search","Recipe"))}
 @Test fun resetDomainHasRoomForEndPoints(){val d=graphViewportRange(0.0,100.0,70.0,80.0);val left=(0-d.minX)/(d.maxX-d.minX);val right=(d.maxX-100)/(d.maxX-d.minX);assertTrue(left>.05);assertTrue(right>.05);assertTrue(d.minY<70);assertTrue(d.maxY>80)}
 @Test fun oneMeasurementHasANonzeroRange(){val d=graphViewportRange(10.0,10.0,75.0,75.0);assertTrue(d.maxX>d.minX);assertTrue(d.maxY>d.minY)}
 @Test fun favouriteLogsExactlyTheSavedAmount(){val i=Ingredient(Food("Oats",nutrients=Nutrients(listOf(400.0,20.0,40.0,12.0,5.0,6.0,8.0,1.0))),70.0);val e=Entry(date="2026-10-25",food=i.food,amount=i.amount,unit=i.unit,unitGrams=i.unitGrams);assertEquals(280.0,e.total()[0]!!,0.00001);assertEquals(14.0,e.total()[1]!!,0.00001)}
}
