package com.example.caloriecounter
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate
class GoalEstimateTest{
 private val today=LocalDate.of(2026,10,25)
 private fun sample()=Profile(completed=true,sex="Male",age=30,height=180.0,weight=80.0,targetWeight=75.0,targetWeightDate=today.plusDays(90).toString(),autoCalorieTarget=true,autoGoalEligible=true)
 @Test fun reasonableEstimate(){val p=sample();val r=calorieGoalEstimate(p,today);assertNotNull(r.calories);assertFalse(r.limited);assertTrue(r.calories!!>=1500)}
 @Test fun deadlineCannotForceCrashDiet(){val r=calorieGoalEstimate(sample().copy(targetWeightDate=today.plusDays(1).toString()),today);assertTrue(r.limited);assertTrue(r.calories!!>=1500)}
 @Test fun pastDatePauses(){assertNull(calorieGoalEstimate(sample().copy(targetWeightDate=today.toString()),today).calories)}
 @Test fun underweightGoalBlocked(){assertNull(calorieGoalEstimate(sample().copy(targetWeight=45.0),today).calories)}
 @Test fun eligibilityRequired(){assertNull(calorieGoalEstimate(sample().copy(autoGoalEligible=false),today).calories)}
 @Test fun gainIsBounded(){val p=sample().copy(targetWeight=90.0,targetWeightDate=today.plusDays(1).toString());val r=calorieGoalEstimate(p,today);assertTrue(r.limited);assertTrue(r.calories!!<=p.estimate()+301)}
 @Test fun widgetHalfFill(){assertEquals(500,calorieFill(1000.0,2000.0))}
 @Test fun widgetClamps(){assertEquals(1000,calorieFill(2500.0,2000.0));assertEquals(0,calorieFill(-10.0,2000.0));assertEquals(0,calorieFill(10.0,0.0))}
}
