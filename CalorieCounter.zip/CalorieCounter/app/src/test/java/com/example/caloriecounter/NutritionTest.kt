package com.example.caloriecounter
import org.junit.Assert.*
import org.junit.Test
class NutritionTest{
 private fun fibre(v:Double?)=Nutrients(listOf(100.0,1.0,2.0,3.0,0.4,0.5,v,0.1))
 @Test fun knownFibreSurvivesUnknownIngredient(){val n=sumNutrients(listOf(fibre(6.7),fibre(null)));assertEquals(6.7,n[6]!!,0.00001);assertEquals(1,n.missing(6))}
 @Test fun allUnknownStaysUnknown(){val n=sumNutrients(listOf(fibre(null),fibre(null)));assertNull(n[6]);assertEquals(2,n.missing(6))}
 @Test fun emptyDayIsZero(){val n=sumNutrients(emptyList());assertEquals(0.0,n[6]!!,0.0);assertEquals(0,n.missing(6))}
 @Test fun partialRecipeSurvivesPortionAndDiary(){val oats=Ingredient(Food("Oats",nutrients=fibre(10.0)),67.0);val honey=Ingredient(Food("Honey",nutrients=fibre(null)),20.0);val r=Recipe(name="Porridge",servings=2,ingredients=listOf(oats,honey));assertEquals(6.7,r.total()[6]!!,0.00001);val e=Entry(date="2026-10-24",food=r.servingFood(),amount=1.0,unit="portion",unitGrams=100.0);assertEquals(3.35,e.total()[6]!!,0.00001);assertEquals(1,e.total().missing(6));val day=sumNutrients(listOf(e.total(),fibre(2.0)));assertEquals(5.35,day[6]!!,0.00001);assertEquals(1,day.missing(6))}
 @Test fun jsonRoundTripRetainsPartial(){val n=sumNutrients(listOf(fibre(6.7),fibre(null)));val saved=json.fromJson(json.toJson(n),Nutrients::class.java);assertEquals(n[6],saved[6]);assertEquals(1,saved.missing(6))}
 @Test fun legacyNutrientsWithoutMissingCounts(){val n=json.fromJson("""{"values":[100,1,2,3,0.4,0.5,null,0.1]}""",Nutrients::class.java);assertNull(n[6]);assertEquals(1,n.missing(6))}
 @Test fun legacyProfileHasNoInventedGoal(){val p=json.fromJson("""{"completed":true,"sex":"Female","age":30,"height":170,"weight":70,"activity":1.2,"targets":[2000,50,260,70,20,90,30,6],"ukFirst":true}""",Profile::class.java);assertNull(p.targetWeight)}
 @Test fun compactReference(){assertEquals("50",compact(50.0));assertEquals("6",compact(6.0))}
 @Test fun weightSerialization(){val r=WeightRecord(7,"2026-10-24",70.5);assertEquals(r,json.fromJson(json.toJson(r),WeightRecord::class.java))}
}
